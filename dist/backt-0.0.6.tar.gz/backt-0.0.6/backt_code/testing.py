from backt_code.main import backtest


bt = backtest(comp = ["AAPL", "NAVI"], o_day = ["2021-08-01", "2021-06-15"], c_day = ["2021-09-01", "2021-09-01"])

print(bt.portfolio_construction())